package com.example.screenink

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

enum class Tool { LASER, PEN, BRUSH, HIGHLIGHTER, ERASER, LINE, ARROW, RECT, OVAL, STAMP }

class DrawView(c: Context) : View(c) {
    var tool = Tool.LASER
    var stamp = "⭐"
    private class Item(val path: Path?, val paint: Paint, val text: String? = null, val x: Float = 0f, val y: Float = 0f)
    private class Pt(val x: Float, val y: Float, val t: Long)
    private val items = ArrayList<Item>()
    private val trail = ArrayList<Pt>()
    private var cur: Path? = null
    private var curPaint: Paint? = null
    private var sx = 0f; private var sy = 0f; private var lx = 0f; private var ly = 0f
    private var down = false
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun i(k: String) = P.i(context, k)
    private fun al(c: Int, v: Int) = (c and 0xFFFFFF) or (v.coerceIn(0, 255) shl 24)
    private fun now() = System.currentTimeMillis()

    private fun pen() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        color = i("color"); strokeWidth = i("penSize").toFloat()
        when (tool) {
            Tool.BRUSH -> { strokeWidth = i("brushSize").toFloat(); alpha = 190 }
            Tool.HIGHLIGHTER -> { strokeWidth = i("hlSize").toFloat(); alpha = 90; strokeCap = Paint.Cap.SQUARE }
            Tool.ERASER -> { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); strokeWidth = i("eraserSize").toFloat() }
            else -> {}
        }
    }

    private fun shape(ax: Float, ay: Float, bx: Float, by: Float): Path {
        val p = Path()
        when (tool) {
            Tool.LINE -> { p.moveTo(ax, ay); p.lineTo(bx, by) }
            Tool.ARROW -> {
                p.moveTo(ax, ay); p.lineTo(bx, by)
                val ang = atan2((by - ay).toDouble(), (bx - ax).toDouble()); val len = maxOf(36f, i("penSize") * 5f)
                for (d in doubleArrayOf(0.5, -0.5)) {
                    p.moveTo(bx, by); p.lineTo(bx - len * cos(ang + d).toFloat(), by - len * sin(ang + d).toFloat())
                }
            }
            Tool.RECT -> p.addRect(minOf(ax, bx), minOf(ay, by), maxOf(ax, bx), maxOf(ay, by), Path.Direction.CW)
            else -> p.addOval(RectF(minOf(ax, bx), minOf(ay, by), maxOf(ax, bx), maxOf(ay, by)), Path.Direction.CW)
        }
        return p
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        when (tool) {
            Tool.LASER -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { down = true; lx = x; ly = y; trail.add(Pt(x, y, now())) }
                    MotionEvent.ACTION_MOVE -> {
                        for (h in 0 until e.historySize) trail.add(Pt(e.getHistoricalX(h), e.getHistoricalY(h), now()))
                        trail.add(Pt(x, y, now())); lx = x; ly = y
                    }
                    else -> down = false
                }
                postInvalidateOnAnimation()
            }
            Tool.STAMP -> if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = i("stampSize").toFloat(); textAlign = Paint.Align.CENTER }
                items.add(Item(null, p, stamp, x, y)); invalidate()
            }
            Tool.LINE, Tool.ARROW, Tool.RECT, Tool.OVAL -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = x; sy = y; curPaint = pen(); cur = shape(x, y, x, y); items.add(Item(cur, curPaint!!)) }
                    MotionEvent.ACTION_MOVE -> if (cur != null) { cur = shape(sx, sy, x, y); items[items.size - 1] = Item(cur, curPaint!!) }
                    else -> cur = null
                }
                invalidate()
            }
            else -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { cur = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y) }; curPaint = pen(); items.add(Item(cur, curPaint!!)); lx = x; ly = y }
                    MotionEvent.ACTION_MOVE -> cur?.let { p ->
                        for (h in 0..e.historySize) {
                            val hx = if (h < e.historySize) e.getHistoricalX(h) else x
                            val hy = if (h < e.historySize) e.getHistoricalY(h) else y
                            p.quadTo(lx, ly, (hx + lx) / 2, (hy + ly) / 2); lx = hx; ly = hy
                        }
                    }
                    else -> cur = null
                }
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val l = cv.saveLayer(null, null)
        for (m in items) {
            if (m.path != null) cv.drawPath(m.path, m.paint) else cv.drawText(m.text!!, m.x, m.y + m.paint.textSize / 3, m.paint)
        }
        cv.restoreToCount(l)
        val t = now(); val fade = i("laserTime").toLong().coerceAtLeast(100)
        val sz = i("laserSize").toFloat(); val col = i("laserColor")
        trail.removeAll { t - it.t > fade }
        gp.style = Paint.Style.STROKE; gp.strokeCap = Paint.Cap.ROUND
        for (k in 1 until trail.size) {
            val a = trail[k - 1]; val b = trail[k]
            val f = (1f - (t - b.t) / fade.toFloat()).coerceIn(0f, 1f)
            gp.color = al(col, (110 * f).toInt()); gp.strokeWidth = sz * 1.8f * f + 2
            cv.drawLine(a.x, a.y, b.x, b.y, gp)
            gp.color = al(col, (255 * f).toInt()); gp.strokeWidth = sz * 0.7f * f + 1
            cv.drawLine(a.x, a.y, b.x, b.y, gp)
        }
        if (down && tool == Tool.LASER) {
            gp.style = Paint.Style.FILL
            gp.color = al(col, 80); cv.drawCircle(lx, ly, sz * 2f, gp)
            gp.color = col; cv.drawCircle(lx, ly, sz, gp)
            gp.color = Color.WHITE; cv.drawCircle(lx, ly, sz * 0.4f, gp)
        }
        if (down || trail.isNotEmpty()) postInvalidateOnAnimation()
    }

    fun undo() { if (items.isNotEmpty()) { items.removeAt(items.size - 1); invalidate() } }
    fun clearAll() { items.clear(); trail.clear(); invalidate() }
}
