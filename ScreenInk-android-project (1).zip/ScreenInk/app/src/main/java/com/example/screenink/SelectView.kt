package com.example.screenink

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class SelectView(c: Context, private val lasso: Boolean, private val done: (Rect?) -> Unit) : View(c) {
    private val path = Path()
    private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f; private var drag = false
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val fill = Paint().apply { color = 0x22FFFFFF }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val glow = Paint(line).apply { strokeWidth = 24f; color = 0x66448AFF }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 48f; textAlign = Paint.Align.CENTER }

    private fun bounds(): Rect {
        if (lasso) { val r = RectF(); path.computeBounds(r, true); return Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()) }
        return Rect(minOf(sx, ex).toInt(), minOf(sy, ey).toInt(), maxOf(sx, ex).toInt(), maxOf(sy, ey).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = sx; ey = sy; drag = true; path.reset(); path.moveTo(sx, sy) }
            MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y; path.lineTo(ex, ey) }
            MotionEvent.ACTION_UP -> {
                drag = false; val b = bounds(); val loc = IntArray(2); getLocationOnScreen(loc); b.offset(loc[0], loc[1])
                done(if (b.width() < 40 || b.height() < 40) null else b); return true
            }
            MotionEvent.ACTION_CANCEL -> { done(null); return true }
        }
        invalidate(); return true
    }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (!drag) { cv.drawText(if (lasso) "✨ Circle anything to ask Gemini" else "✂️ Drag to select an area", width / 2f, 140f, txt); return }
        if (lasso) { cv.drawPath(path, glow); cv.drawPath(path, line) }
        else { val r = RectF(bounds()); cv.drawRect(r, fill); cv.drawRect(r, line) }
    }
}
