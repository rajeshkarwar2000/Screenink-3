package com.example.screenink

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class CaptureActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
    }
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        val i = Intent(this, OverlayService::class.java)
        if (rc == RESULT_OK && d != null) i.setAction("PROJ").putExtra("code", rc).putExtra("data", d) else i.setAction("DENIED")
        startService(i); finish()
    }
}
